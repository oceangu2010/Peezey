﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FirstDataPayment;
using System.Xml;
using System.Runtime.Serialization.Json;
using System.IO;

namespace Demo.Handler
{
    /// <summary>
    /// PaymentRequest 的摘要说明
    /// </summary>
    public class PaymentRequest : IHttpHandler
    {
        HttpContext _content;
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plan";
            _content = context;
            IFirstDataPayment payment = new PaymentManage();
            RequestParameters param = GetRequestParam();
            TransactionResponse response;
            if(param.RequestModel.transaction_type=="purchase")
                response = payment.PurchaseTransaction(param);
            else
                response = payment.AuthorizeTransaction(param);
            //param.TransacionId = response.TransactionId;
            //param.TransacionId = "ET149238";
            ////param.RequestModel.transaction_tag = response.TransactionTag;
            //param.RequestModel.transaction_tag = "48496760";

            //ProcessRequest pr = new ProcessRequest();
            //pr.amount = param.RequestModel.amount;
            //pr.currency_code = param.RequestModel.currency_code;
            //pr.merchant_ref = param.RequestModel.merchant_ref;
            //pr.method = param.RequestModel.method;
            ////pr.transaction_tag = response.TransactionTag;
            //pr.transaction_tag = "48496760";
            //pr.transaction_type = param.RequestModel.transaction_type;
            //param.RequestModel = pr;
            //TransactionResponse RefundResponse = payment.PurchaseTransaction(param);
            //string result = Newtonsoft.Json.JsonConvert.SerializeObject(RefundResponse);
            //XmlDocument doc = Newtonsoft.Json.JsonConvert.DeserializeXmlNode(result, "Response");


            //EventsResponse ep = new EventsResponse();
            //EventsParameters eparam = new EventsParameters();
            //eparam.FromDate = "2015-03-14";
            //eparam.ToDate = "2015-03-15";
            //eparam.Offset = "10";
            //eparam.Limit = "10";
            //eparam.EventType = "TRANSACTION_STATUS";
            //API api = new API();
            //api.Key = GetFromNameStr("apikey");
            //api.Secret = GetFromNameStr("secret");
            //api.Nonce = GetFromNameStr("nonce");
            //api.Timestamp = GetFromNameStr("timestamp");
            //api.Token = GetFromNameStr("token");
            ////var a = payment.SearchForEvents(eparam, api);
            //eparam.EventId = "8a34e7644be661c8014c1be2749507f3";
            //var item= payment.GetEventByID(eparam, api);
            if (response!=null)
                context.Response.Write(param.RequestModel.transaction_type + " success!");
            else
                context.Response.Write(param.RequestModel.transaction_type+" failure!");
        }

        private RequestParameters GetRequestParam() 
        {
            RequestParameters paramModel = new RequestParameters();
            //paramModel.Payload = GetPayload();
            paramModel.RequestModel = GetRequestModel();
            paramModel.Api = new API();
            paramModel.Api.Key = GetFromNameStr("apikey");
            paramModel.Api.Secret = GetFromNameStr("secret");
            //paramModel.Api.Nonce = GetFromNameStr("nonce");
            //paramModel.Api.Timestamp = GetFromNameStr("timestamp");
            paramModel.Api.Token = GetFromNameStr("token");
            return paramModel;
        }

        private string GetPayload() 
        {
            string amount = GetFromNameStr("amount");
            string currency_code = "USD";
            string transaction_type = GetFromNameStr("transaction_type");
            string merchant_ref = "Astonishing-Sale";

            string tokentype = GetFromNameStr("tokentype");
            if (tokentype.ToLower() != TokenType.payeezy.ToString().ToLower())
            {
                TransactionRequest model = new TransactionRequest();
                model.credit_card = new Card();
                model.credit_card.CVV = GetFromNameStr("cvv_code");
                model.credit_card.ExpDate = GetFromNameStr("exp_month") + GetFromNameStr("exp_year");
                model.credit_card.CardHolderName = GetFromNameStr("cardholder_name");
                model.credit_card.CardType = GetFromNameStr("card_type");
                model.credit_card.CardNumber = GetFromNameStr("cc_number");

                model.amount = amount;
                model.currency_code = currency_code;
                model.method = "credit_card";
                model.transaction_type = transaction_type;
                model.merchant_ref = merchant_ref;
                string payload=Newtonsoft.Json.JsonConvert.SerializeObject(model);
                return payload;
            }
            else
            {
                TokenRequest model = new TokenRequest();
                model.token = new Token();
                model.token.TokenType = "payeezy";
                model.token.TokenData = new Token_data();
                model.token.TokenData.Value = GetFromNameStr("payeezyToken");

                model.amount = amount;
                model.currency_code = currency_code;
                model.method = "token";
                model.transaction_type = transaction_type;
                model.merchant_ref = merchant_ref;
                string payload = Newtonsoft.Json.JsonConvert.SerializeObject(model);
                return payload;
            }   

            
        }


        //private IRequestModel GetRequestModel() 
        //{
        //    IRequestModel request = null;
        //    string tokentype = GetFromNameStr("tokentype");
        //    string method = string.Empty;
        //    if (tokentype.ToLower() != TokenType.payeezy.ToString().ToLower())
        //    {
        //        method = "credit_card";
        //        request = new TransactionRequest();
        //    }
        //    else {
        //        method = "token";
        //        request = new TokenRequest();
        //        request.token = new Token();
        //        request.token.token_type = "payeezy";
        //        request.token.token_data = new Token_data();
        //        request.token.token_data.value = GetFromNameStr("payeezyToken");
        //    }
        //    string currency_code = "USD";
        //    string merchant_ref = "Astonishing-Sale";
        //    request.amount = GetFromNameStr("amount");
        //    request.currency_code = currency_code;
        //    request.method = method;
        //    request.transaction_type = GetFromNameStr("transaction_type");
        //    request.merchant_ref = merchant_ref;
        //    return request;
        //}

        private RequestModel GetRequestModel() 
        {
            string amount = GetFromNameStr("amount");
            string transaction_type = GetFromNameStr("transaction_type");
            string merchant_ref = GetFromNameStr("merchant_ref");

            string tokentype = GetFromNameStr("tokentype");
            if (tokentype.ToLower() != TokenType.payeezy.ToString().ToLower())
            {
                TransactionRequest model = new TransactionRequest();
                model.credit_card = new Card();
                model.credit_card.CVV = GetFromNameStr("cvv_code");
                model.credit_card.ExpDate = GetFromNameStr("exp_month") + GetFromNameStr("exp_year");
                model.credit_card.CardHolderName = GetFromNameStr("cardholder_name");
                model.credit_card.CardType = GetFromNameStr("card_type");
                model.credit_card.CardNumber = GetFromNameStr("cc_number");

                model.amount = amount;
                model.transaction_type = transaction_type;
                model.merchant_ref = merchant_ref;
                return model;
            }
            else
            {
                TokenRequest model = new TokenRequest();
                model.token = new Token();
                model.token.TokenType = "payeezy";
                model.token.TokenData = new Token_data();
                model.token.TokenData.Value = GetFromNameStr("payeezyToken");

                model.amount = amount;
                model.method = "token";
                model.transaction_type = transaction_type;
                model.merchant_ref = merchant_ref;
                return model;
            }  
        }

        private string GetFromNameStr(string key)
        {
            if (_content == null) return string.Empty;
            if (_content.Request.Form[key] == null)
                return string.Empty;
            return _content.Request.Form[key].Trim().ToString();
        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}