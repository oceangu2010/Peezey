﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FirstDataPayment;

namespace Demo.Handler
{
    /// <summary>
    /// SearchEvent 的摘要说明
    /// </summary>
    public class SearchEvent : IHttpHandler
    {
        HttpContext _content;
        public void ProcessRequest(HttpContext context)
        {
            _content = context;
            context.Response.ContentType = "application/json";
            //context.Response.ContentType = "text/plan";
            IFirstDataPayment payment = new PaymentManage();

            EventsResponse ep = new EventsResponse();
            EventsParameters eparam = GetParam();
            List<EventsResponse> responses = payment.SearchForEvents(eparam, GetApi());
            //foreach (var item in responses)
            //{
            //    if (string.IsNullOrEmpty(item.Message.TransactionTime))
            //        continue;
            //    long ticks = Convert.ToInt64(item.Message.TransactionTime);
            //    item.Message.TransactionTime = new DateTime(ticks).ToString("yy-MM-dd");
            //}
            responses = responses.OrderByDescending(r => r.CreateTime).ToList();

            string jsonstr = Newtonsoft.Json.JsonConvert.SerializeObject(responses);
            context.Response.Write(jsonstr);
        }

        private EventsParameters GetParam() 
        {
            EventsParameters eparam = new EventsParameters();
            eparam.FromDate = GetFromNameStr("fromDate");
            eparam.ToDate = GetFromNameStr("toDate");
            eparam.Offset = GetFromNameStr("pageSize");
            eparam.Limit = GetFromNameStr("pageNumber");
            eparam.EventType = "TRANSACTION_STATUS";
            return eparam;
        }
        private API GetApi() 
        {
            API api = new API();
            api.Key = GetFromNameStr("apikey");
            api.Secret = GetFromNameStr("secret");
            api.Nonce = GetFromNameStr("nonce");
            api.Timestamp = GetFromNameStr("timestamp");
            api.Token = GetFromNameStr("token");
            return api;
        }

        private string GetFromNameStr(string key)
        {
            if (_content == null) return string.Empty;
            if (_content.Request.Form[key] == null)
                return string.Empty;
            return _content.Request.Form[key].Trim().ToString();
        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}