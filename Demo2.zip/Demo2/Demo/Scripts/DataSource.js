﻿/// <reference path="jquery-1.8.3.min.js" />

var DataSource =
{
    TransationList: function (args) {
        var param = {
            apikey: "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a",
            secret: "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7",
            token: "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6",
            nonce: Math.random() * 1000000000000000000,
            timestamp: new Date().getTime(),
            fromDate: "",
            toDate: "",
            pageSize: "",
            pageNumber: ""
        }
        param = $.extend(param, args);
        var dataJson = null;
        $.ajax({
            type: "post",
            data: param,
            dataType: "json",
            url: "Handler/SearchEvent.ashx",
            async: false,
            success: function (data) {
                dataJson = data ;
            }, error: function (err) {
                alert("js error!");
            }
        });
        return dataJson;
    }
}