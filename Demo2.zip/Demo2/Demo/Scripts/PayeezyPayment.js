﻿var Api = {
    key: "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a",
    Secret: "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7",
    MercId: "",
    Token: "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6",
    PayeezyToken: ""
}


$(function () {
    $('#payment_info_form').submit(function (e) {
        var $form = $(this);
        var nonce = Math.random() * 1000000000000000000;
        var timestamp = new Date().getTime();

        //        Api.key = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
        //        Api.Token = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
        //        Api.Secret = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";

        $form.attr("action", "Handler/PaymentRequest.ashx");
        $form.attr("method", "post");
        $form.append($('<input type="hidden" name="token"/>').val(Api.Token));
        $form.append($('<input type="hidden" name="payeezyToken"/>').val(Api.PayeezyToken));
        $form.append($('<input type="hidden" name="nonce"/>').val(nonce));
        $form.append($('<input type="hidden" name="timestamp"/>').val(timestamp));
        $form.append($('<input type="hidden" name="secret"/>').val(Api.Secret));
        $form.append($('<input type="hidden" name="apikey"/>').val(Api.key));
        //$form.get(0).submit();
    });

    $("#btnGetToken").click(function () {
        Payeezy.setApiKey(Api.key);
        var trtoken = "y6pzAbc3Def123";
        Payeezy.setMerchantIdentifier(trtoken);
        Payeezy.createToken(responseHandler);
    });
})



function responseHandler(status, response) {
    var $form = $('#payment_info_form');
    if (status != 201) {
        if (response.error) {
            var errorMessages = response.error.messages;
            var allErrors = '';
            for (i = 0; i < errorMessages.length; i++) {
                allErrors = allErrors + errorMessages[i].description;
            }
            $form.find('.payment-errors').text("status:" + status + ", " + allErrors);
        }
        $form.find('button').prop('disabled', false);
    } else {
        var payeezyToken = response.token.value;
        var nonce = Math.random() * 1000000000000000000;
        var timestamp = new Date().getTime();
        Api.PayeezyToken = payeezyToken;
        $form.find('.payment-errors').text("get payeezy token success");
    }
}