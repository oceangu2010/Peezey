﻿/// <reference path="jquery-1.8.3.min.js" />
var list;
$(function () {
    var date = new Date();
    var from = date.getFullYear() + "-" + GetMonthStr(parseInt(date.getMonth()) + 1) + "-" + (parseInt(date.getDate()) - 1);
    var to = date.getFullYear() + "-" + GetMonthStr(parseInt(date.getMonth()) + 1) + "-" + date.getDate();
    $("#txtFrom").val(from);
    $("#txtTo").val(to);

    $("#btnGetData").click(function () {
        var args = {
            fromDate: $("#txtFrom").val(),
            toDate: $("#txtTo").val(),
            pageSize: $("#txtPageSize").val(),
            pageNumber: $("#txtPageNum").val()
        }
        list = DataSource.TransationList(args);
        InitTable(list);
    });

    $("#btnSearch").click(function () {
        if (!list) return;
        var tempList = [];
        var ref = $("#txtref").val();
        var amount = $("#txtAmount").val();

        var k = 0;
        for (var i = 0; i < list.length; i++) {
            var flag = false;
            if (ref && list[i].message.ref_data && list[i].message.ref_data.indexOf(ref) > -1) {
                list[i].message.ref_data = list[i].message.ref_data.replace(ref, "<span style='color:red;'>" + ref + "</span>");
                flag = true;
            }
            if (amount && list[i].message.amount.indexOf(amount) > -1) {
                list[i].message.amount = list[i].message.amount.replace(amount, "<span style='color:red;'>" + amount + "</span>");
                flag = true;
            }
            if (flag) {
                tempList[k] = list[i];
                k++;
            }
        }

        if (tempList && tempList.length > 0)
            InitTable(tempList);
    });

    $(".spanEventId").click(function () {
        alert($(this).text());
    });
})

function GetMonthStr(month) {
    var m = parseInt(month);
    if (m < 10)
        return "0" + m;
    return m;
}

function InitTable(list) {
    var $table = $("#tbTransactionList");
    $table.html("");
    
    var head = "<tr>" +
                '<td align="center">EventId</td>' +
                '<td align="center">EventType</td>' +
                '<td align="center">Event Create Time</td>' +
                '<td align="center">transaction_id</td>' +
                '<td align="center">transaction_tag</td>' +
                '<td align="center">currency</td>' +
                '<td align="center">amount</td>' +
                '<td align="center">status</td>' +
                '<td align="center">transaction_type</td>' +
                '<td align="center">transaction_time</td>' +
                '<td align="center">ref_data</td>' +
            '</tr>';
    $table.append(head);
    $.each(list, function (i,item) {
        var trstr = "<tr>";
        trstr += "<td><span class='spanEventId' >" + item.id + "</span></td>";
        trstr += "<td>" + item.eventType + "</td>";
        trstr += "<td>" + item.createTime + "</td>";
        trstr += "<td>" + item.message.transaction_id + "</td>";
        trstr += "<td>" + item.message.transaction_tag + "</td>";
        trstr += "<td>" + item.message.currency + "</td>";
        trstr += "<td>" + item.message.amount + "</td>";
        trstr += "<td>" + item.message.status + "</td>";
        trstr += "<td>" + item.message.transaction_type + "</td>";
        trstr += "<td>" + item.message.transaction_time + "</td>";
        trstr += "<td>" + item.message.ref_data + "</td>";
        trstr += "</tr>";
        $table.append(trstr);
    });
    $("#spanSum").text(list.length);
}
