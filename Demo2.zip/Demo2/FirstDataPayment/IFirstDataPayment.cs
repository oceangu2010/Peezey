﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    public interface IFirstDataPayment
    {
        /// <summary>
        /// payment mode
        /// </summary>
        bool PaymentTestMode { set; }
        /// <summary>
        /// Purchase
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        TransactionResponse PurchaseTransaction(RequestParameters parameters);
        /// <summary>
        /// Authorize
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        TransactionResponse AuthorizeTransaction(RequestParameters parameters);
        /// <summary>
        /// Capture
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        //TransactionResponse CaptureTransaction(RequestParameters parameters);
        /// <summary>
        /// Refund
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        TransactionResponse RefundTransaction(RequestParameters parameters);
        /// <summary>
        /// Void 
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        TransactionResponse VoidTransaction(RequestParameters parameters);
        /// <summary>
        /// Call this method to get workflow and boarding status updates. 
        /// </summary>
        /// <param name="EventsParam">event id is optional</param>
        /// <param name="api"></param>
        /// <returns></returns>
        List<EventsResponse> SearchForEvents(EventsParameters EventsParam, API api);
        /// <summary>
        /// Get information for a specific event given an event id
        /// </summary>
        /// <param name="EventsParam">need event id</param>
        /// <param name="api"></param>
        /// <returns></returns>
        EventsResponse GetEventByID(EventsParameters EventsParam,API api);
    }
}
