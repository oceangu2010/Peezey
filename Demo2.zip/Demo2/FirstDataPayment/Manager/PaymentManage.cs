﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Security.Cryptography;
using System.Runtime.Serialization.Json;

namespace FirstDataPayment
{
    public class PaymentManage : IFirstDataPayment
    {
        private string url ="https://api-cert.payeezy.com/v1";
        private const String NONCE = "nonce";
        private const String APIKEY = "apikey";
        private const String APISECRET = "pzsecret";
        private const String TOKEN = "token";
        private const String TIMESTAMP = "timestamp";
        private const String AUTHORIZE = "Authorization";
        private const String PAYLOAD = "payload";
        private const String OVERRIDE = "override";
        public bool PaymentTestMode
        {
            set
            {
                if (!value)
                    url = "https://api.payeezy.com/v1";
            }
        }

        public PaymentManage() 
        {
                
        }

        private TransactionResponse PrimaryTransaction(RequestParameters requestParameter)
        {
            try
            {
                string payload = Newtonsoft.Json.JsonConvert.SerializeObject(requestParameter.RequestModel);
                string result = string.Empty;
                string postUrl = url + "/transactions/";
                var webRequest = (HttpWebRequest)WebRequest.Create(postUrl);
                webRequest.Method = "POST";
                webRequest.ContentLength = payload.Length;
                webRequest.ContentType = "application/json";
                InitHeaders(webRequest.Headers, requestParameter.Api,payload);

                StreamWriter myWriter = null;
                using (myWriter = new StreamWriter(webRequest.GetRequestStream()))
                {
                    myWriter.Write(payload);
                }

                var response = (HttpWebResponse)webRequest.GetResponse();
                TransactionResponse responseModel = (TransactionResponse)new DataContractJsonSerializer((new TransactionResponse()).GetType()).ReadObject(response.GetResponseStream());
                if (!string.IsNullOrEmpty(responseModel.TransactionStatus) && responseModel.TransactionStatus.ToLower() == "approved")
                    responseModel.Approved = true;
                else
                    responseModel.Approved = false;
                return responseModel;
            }
            catch (Exception ex) {
                throw ex;
            }
        }

        private TransactionResponse SecondaryTransaction(RequestParameters requestParameter) 
        {
            try
            {
                string payload = Newtonsoft.Json.JsonConvert.SerializeObject(requestParameter.RequestModel);
                string result = string.Empty;
                string postUrl = url + "/transactions/" + requestParameter.TransacionId;
                var webRequest = (HttpWebRequest)WebRequest.Create(postUrl);
                webRequest.Method = "POST";
                webRequest.ContentLength = payload.Length;
                webRequest.ContentType = "application/json";
                InitHeaders(webRequest.Headers, requestParameter.Api,payload);

                StreamWriter myWriter = null;
                using (myWriter = new StreamWriter(webRequest.GetRequestStream()))
                {
                    myWriter.Write(payload);
                }
                var response = (HttpWebResponse)webRequest.GetResponse();
                TransactionResponse responseModel = (TransactionResponse)new DataContractJsonSerializer((new TransactionResponse()).GetType()).ReadObject(response.GetResponseStream());
                return responseModel;
            }
            catch (Exception ex) {
                throw ex;
            }
        }
        /// <summary>
        /// Purchase
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public TransactionResponse PurchaseTransaction(RequestParameters parameters)
        {
            parameters.RequestModel.transaction_type = TransactionType.PURCHASE.ToString();
            return PrimaryTransaction(parameters);
        }
        /// <summary>
        /// Authorize
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public TransactionResponse AuthorizeTransaction(RequestParameters parameters)
        {
            parameters.RequestModel.transaction_type = TransactionType.AUTHORIZE.ToString();
            return PrimaryTransaction(parameters);
        }
        /// <summary>
        /// Capture
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public TransactionResponse CaptureTransaction(RequestParameters parameters)
        {
            parameters.RequestModel.transaction_type = TransactionType.CAPTURE.ToString();
            return PrimaryTransaction(parameters);
        }

        /// <summary>
        /// Refund
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public TransactionResponse RefundTransaction(RequestParameters parameters)
        {
            parameters.RequestModel.transaction_type = TransactionType.REFUND.ToString();
            return SecondaryTransaction(parameters);
        }
        /// <summary>
        /// Void 
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public TransactionResponse VoidTransaction(RequestParameters parameters)
        {
            parameters.RequestModel.transaction_type = TransactionType.VOID.ToString();
            return SecondaryTransaction(parameters);
        }
        /// <summary>
        /// Call this method to get workflow and boarding status updates. 
        /// </summary>
        /// <param name="EventsParam">event id is optional</param>
        /// <param name="api"></param>
        /// <returns></returns>
        public List<EventsResponse> SearchForEvents(EventsParameters EventsParam, API api) 
        {
            try
            {
                string payload = Newtonsoft.Json.JsonConvert.SerializeObject(EventsParam);
                string postUrl = url + "/events?from=" + EventsParam.FromDate
                    + "&to=" + EventsParam.ToDate
                    + "&eventType=" + EventsParam.EventType;
                var webRequest = (HttpWebRequest)WebRequest.Create(postUrl);
                webRequest.ContentType = "application/json";
                InitHeaders(webRequest.Headers, api,payload);
                webRequest.Method = "GET";
                var response = (HttpWebResponse)webRequest.GetResponse();
                List<EventsResponse> responseModels = (List<EventsResponse>)new DataContractJsonSerializer((new List<EventsResponse>()).GetType()).ReadObject(response.GetResponseStream());
                return responseModels;
            }
            catch (Exception ex) {
                throw ex;
            }
        }

        /// <summary>
        /// Get information for a specific event given an event id
        /// </summary>
        /// <param name="EventsParam">need event id</param>
        /// <param name="api"></param>
        /// <returns></returns>
        public EventsResponse GetEventByID(EventsParameters EventsParam, API api)
        {
            try
            {
                string payload = Newtonsoft.Json.JsonConvert.SerializeObject(EventsParam);
                string postUrl = url + "/events/" + EventsParam.EventId;
                var webRequest = (HttpWebRequest)WebRequest.Create(postUrl);
                InitHeaders(webRequest.Headers, api,payload);
                webRequest.Method = "GET";
                var response = (HttpWebResponse)webRequest.GetResponse();
                EventsResponse responseModel = (EventsResponse)new DataContractJsonSerializer((new EventsResponse()).GetType()).ReadObject(response.GetResponseStream());
                return responseModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void InitHeaders(WebHeaderCollection quest,API api,string payload)
        {
            Dictionary<string, string> map = GetSecurityKeys(api,payload);
            foreach (var item in map)
            {
                switch (item.Key)
                { 
                    case APIKEY:
                    case TOKEN:
                    case AUTHORIZE:
                        quest.Add(item.Key, item.Value);
                        break;
                }
            }
        }
        private Dictionary<string, string> GetSecurityKeys(API api,string payload)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            try
            {
                map.Add(NONCE, api.Nonce);
                map.Add(APIKEY, api.Key);
                map.Add(TIMESTAMP, api.Timestamp);
                map.Add(TOKEN, api.Token);
                map.Add(APISECRET, api.Secret);
                map.Add(PAYLOAD, payload);
                map.Add(AUTHORIZE, GetHMAC(map));
                return map;
            }
            catch (Exception ex)
            {
                return null;
                throw new Exception(ex.ToString());
            }
        }
        private string GetHMAC(Dictionary<string, string> map)
        {
            HMAC mac = HMAC.Create("HMACSHA256");
            mac.Key = Encoding.UTF8.GetBytes(map[APISECRET]);
            StringBuilder buff = new StringBuilder();
            buff.Append(map[APIKEY]);
            buff.Append(map[NONCE]);
            buff.Append(map[TIMESTAMP]);
            if (!string.IsNullOrEmpty(map[TOKEN]))
                buff.Append(map[TOKEN]);
            if (!string.IsNullOrEmpty(map[PAYLOAD]))
                buff.Append(map[PAYLOAD]);

            byte[] macHash = mac.ComputeHash(Encoding.UTF8.GetBytes(buff.ToString()));
            String authorizeString = Convert.ToBase64String(macHash);
            return authorizeString;
        }
    }
}
