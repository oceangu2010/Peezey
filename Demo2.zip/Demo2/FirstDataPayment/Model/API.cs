﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    [Serializable]
    public class API
    {

        public API() {
            this.Nonce = new Random().Next(100000000).ToString();
            this.Timestamp = DateTime.Now.Ticks.ToString();
        }
        /// <summary>
        /// required
        /// </summary>
        public string Key { get; set; }
        /// <summary>
        /// required
        /// </summary>
        public string Secret { get; set; }
        /// <summary>
        /// required
        /// </summary>
        public string Token { get; set; }
        /// <summary>
        /// optional
        /// </summary>
        public string Nonce { get; set; }
        /// <summary>
        /// optional
        /// </summary>
        public string Timestamp { get; set; }
    }
}
