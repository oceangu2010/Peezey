﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace FirstDataPayment
{
    [Serializable]
    [DataContract]
    public class Card
    {
        [DataMember(Name = "type")]
        public String CardType { get; set; }
        [DataMember(Name = "cardholder_name")]
        public String CardHolderName { get; set; }
        [DataMember(Name = "card_number")]
        public String CardNumber { get; set; }
        [DataMember(Name = "exp_date")]
        public String ExpDate { get; set; }
        [DataMember(Name = "cvv")]
        public String CVV { get; set; }
    }
}
