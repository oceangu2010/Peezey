﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace FirstDataPayment
{
    /// <summary>
    /// error message list
    /// </summary>
    [DataContract(Name = "Error")]
    public class Error
    {
        [DataMember(Name = "messages")]
        public List<ErrorMessage> ErrorMessages { get; set; }
    }

    /// <summary>
    /// error message
    /// </summary>
    [Serializable]
    [DataContract]
    public class ErrorMessage
    {
        [DataMember(Name = "code")]
        public string Code { get; set; }
        [DataMember(Name = "description")]
        public string Description { get; set; }
    }
}
