﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    public class EventsParameters
    {
        public EventsParameters() 
        {
            this.EventType = "TRANSACTION_STATUS";
        }
        /// <summary>
        /// Use Get Event by ID
        /// </summary>
        public string EventId { get; set; }

        public string EventType { get; set; }
        /// <summary>
        /// format yyyy-mm-dd
        /// </summary>
        public string FromDate { get; set; }
        /// <summary>
        /// format yyyy-mm-dd
        /// </summary>
        public string ToDate { get; set; }
        /// <summary>
        ///  Page Size
        /// </summary>
        public string Offset { get; set; }
        /// <summary>
        /// size of page
        /// </summary>
        public string Limit { get; set; }
    }
}
