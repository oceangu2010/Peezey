﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace FirstDataPayment
{
    [Serializable]
    [DataContract]
    public class EventsResponse
    {
        [DataMember(Name="id")]
        public string Id { get; set; }
        [DataMember(Name = "eventType")]
        public string EventType { get; set; }
        [DataMember(Name = "message")]
        public TransationData Message { get; set; }
        [DataMember(Name = "createTime")]
        public string CreateTime { get; set; }

        [DataMember(Name="Error")]
        public Error Error { get; set; }
        [DataMember(Name = "correlation_id")]
        public string CorrelationId { get; set; }

    }

    [Serializable]
    [DataContract]
    public class Message 
    {
        [DataMember(Name = "data")]
        public TransationData TransationData { get; set; }
        [DataMember(Name="event")]
        public string EventName { get; set; }
    }
    [Serializable]
    [DataContract]
    public class TransationData
    {
        [DataMember(Name = "currency")]
        public string Currency { get; set; }
        [DataMember(Name = "status")]
        public string Status { get; set; }
        [DataMember(Name = "ref_data")]
        public string RefData { get; set; }
        [DataMember(Name = "amount")]
        public string Amount { get; set; }
        [DataMember(Name = "transaction_tag")]
        public string TransactionTag { get; set; }
        [DataMember(Name = "transaction_type")]
        public string TransactionType { get; set; }
        [DataMember(Name = "transaction_id")]
        public string TransactionId { get; set; }
        [DataMember(Name = "transaction_time")]
        public string TransactionTime { get; set; }

    }
}
