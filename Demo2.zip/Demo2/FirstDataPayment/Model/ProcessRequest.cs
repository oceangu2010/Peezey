﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    /// <summary>
    /// use 'void', 'refund', 'Capture'.
    /// </summary>
    [Serializable]
    public class ProcessRequest : RequestModel
    {
    }
}
