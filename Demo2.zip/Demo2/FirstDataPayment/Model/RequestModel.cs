﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    /// <summary>
    /// Request the basic information
    /// </summary>
    [Serializable]
    public class RequestModel
    {
        public RequestModel() 
        {
            this.method = "credit_card";
            this.currency_code = "USD";
        }
        /// <summary>
        /// optional
        /// </summary>
        public String merchant_ref { get; set; }
        public String transaction_type { get; set; }
        /// <summary>
        /// optional
        /// </summary>
        public String method { get; set; }
        public String amount { get; set; }
        /// <summary>
        /// optional
        /// </summary>
        public String currency_code { get; set; }
    }
}
