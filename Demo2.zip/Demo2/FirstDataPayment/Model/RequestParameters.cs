﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    /// <summary>
    ///Parameters 
    /// </summary>
    [Serializable]
    public class RequestParameters
    {
        public string TransacionId { get; set; }

        public API Api { get; set; }

        public RequestModel RequestModel { get; set; }
    }
}
