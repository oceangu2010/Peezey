﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace FirstDataPayment
{
    [Serializable]
    [DataContract]
    public class Token
    {
        [DataMember(Name = "token_type")]
        public string TokenType { get; set; }
        [DataMember(Name = "token_data")]
        public Token_data TokenData { get; set; }
    }

    [Serializable]
    [DataContract]
    public class Token_data
    {
        /// <summary>
        /// Time-Bound Single-Use
        /// </summary>
        [DataMember(Name = "value")]
        public string Value { get; set; }
    }

    public enum TokenType
    {
        /// <summary>
        /// Time-Bound Single-Use
        /// </summary>
        payeezy,
        /// <summary>
        /// Multi-Use
        /// </summary>
        transarmor
    }
}
