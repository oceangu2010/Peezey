﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    /// <summary>
    /// Token Based Payments 
    /// </summary>
    [Serializable]
    public class TokenRequest : RequestModel
    {
        /// <summary>
        /// token object
        /// </summary>
        public Token token { get; set; }
    }
}
