﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    /// <summary>
    /// Token Based Payments 
    /// </summary>
    [Serializable]
    public class TransactionRequest : RequestModel
    {
        public Card credit_card { get; set; }
    }
}
