﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace FirstDataPayment
{
    [Serializable]
    [DataContract]
    public class TransactionResponse
    {
        [DataMember(Name = "transaction_status")]
        public String TransactionStatus { get; set; }
        [DataMember(Name = "validation_status")]
        public String ValidationStatus { get; set; }
        [DataMember(Name = "transaction_type")]
        public String TransactionType { get; set; }
        [DataMember(Name = "transaction_id")]
        public String TransactionId { get; set; }
        [DataMember(Name = "transaction_tag")]
        public String TransactionTag { get; set; }
        [DataMember(Name = "method")]
        public String Method { get; set; }
        [DataMember(Name = "amount")]
        public String Amount { get; set; }
        [DataMember(Name = "currency")]
        public String Currency { get; set; }
        [DataMember(Name = "avs")]
        public String AVS { get; set; }
        [DataMember(Name = "cvv2")]
        public String CVV2 { get; set; }
        [DataMember(Name = "transarmor_token")]
        public String TransarmorToken { get; set; }
        [DataMember(Name = "card")]
        public Card Card { get; set; }
        [DataMember(Name = "token")]
        public Token Token { get; set; }
        [DataMember(Name = "Error")]
        public Error Error { get; set; }
        [DataMember(Name = "correlation_id")]
        public String CorrelationId { get; set; }
        [DataMember(Name = "bank_resp_code")]
        public String BankRespCode { get; set; }
        [DataMember(Name = "bank_message")]
        public String BankMessage { get; set; }
        [DataMember(Name = "gateway_resp_code")]
        public String GatewayRespCode { get; set; }
        [DataMember(Name = "gateway_message")]
        public String GatewayMessage { get; set; }

        public Boolean Approved { get; set; }
    }
}
