﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstDataPayment
{
    /// <summary>
    /// transation type
    /// </summary>
    public enum TransactionType
    {
        PURCHASE,
        AUTHORIZE,
        CAPTURE,
        REFUND,
        VOID
    }
}
